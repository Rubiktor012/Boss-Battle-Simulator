﻿Public Class Form1
    Dim PlayerHP As Integer = 100
    Dim PlayerMP As Integer = 50
    Dim EnemyHP As Integer
    Dim PlayerAttack As Integer
    Dim EnemyAttack As Integer
    Dim TotalHeal As Integer
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        BossBattle()
        btnStart.Enabled = False
    End Sub

    Function BossBattle()
        EnemyHP = 200
        pgrEnemyHealth.Maximum = EnemyHP
        btnActionAttack.Enabled = True
        If Not PlayerMP < 8 Then
            btnActionSpecial.Enabled = True
        ElseIf PlayerMP < 8 Then
            btnActionSpecial.Enabled = False
        End If
        If Not PlayerMP < 15 Then
            btnActionHeal.Enabled = True
        ElseIf PlayerMP < 15 Then
            btnActionHeal.Enabled = False
        End If
        pgrPlayerHealth.Value = PlayerHP
        pgrPlayerMagic.Value = PlayerMP
        pgrEnemyHealth.Value = EnemyHP
    End Function

    Function RestartGame()
        PlayerHP = 100
        PlayerMP = 50
        btnActionAttack.Enabled = False
        btnActionSpecial.Enabled = False
        btnActionHeal.Enabled = False
        btnStart.Enabled = True
    End Function

    Private Sub btnActionAttack_Click(sender As Object, e As EventArgs) Handles btnActionAttack.Click
        PlayerAttack = Rnd(7) + 6 'Damage from 6 to 12 towards enemy.
        EnemyAttack = Rnd(11) + 10 'Damage from 10 to 20 towards player.

        EnemyHP = EnemyHP - PlayerAttack
        PlayerHP = PlayerHP - EnemyAttack

        PlayerMP = PlayerMP + 3

        If PlayerMP > 50 Then
            PlayerMP = 50
        End If

        If PlayerHP < 0 Then
            PlayerHP = 0
        End If

        If EnemyHP < 0 Then
            EnemyHP = 0
        End If

        If Not PlayerMP < 8 Then
            btnActionSpecial.Enabled = True
        ElseIf PlayerMP < 8 Then
            btnActionSpecial.Enabled = False
        End If

        If Not PlayerMP < 15 Then
            btnActionHeal.Enabled = True
        ElseIf PlayerMP < 15 Then
            btnActionHeal.Enabled = False
        End If

        pgrPlayerHealth.Value = PlayerHP
        pgrPlayerMagic.Value = PlayerMP
        pgrEnemyHealth.Value = EnemyHP

        If PlayerHP < 1 Then
            lblBattleText.Text = "You Died!"
            lblBattleText.ForeColor = Color.Red
            RestartGame()
        End If

        If EnemyHP < 1 Then
            lblBattleText.Text = "You Won!"
            lblBattleText.ForeColor = Color.Green
            RestartGame()
        End If
    End Sub

    Private Sub btnActionSpecial_Click(sender As Object, e As EventArgs) Handles btnActionSpecial.Click
        PlayerAttack = Rnd(9) + 7 'Damage from 7 to 15 towards enemy.
        EnemyAttack = Rnd(11) + 10 'Damage from 10 to 20 towards player.

        EnemyHP = EnemyHP - PlayerAttack
        PlayerHP = PlayerHP - EnemyAttack

        PlayerMP = PlayerMP - 8

        If PlayerMP > 50 Then
            PlayerMP = 50
        End If

        If PlayerHP < 0 Then
            PlayerHP = 0
        End If

        If EnemyHP < 0 Then
            EnemyHP = 0
        End If

        If Not PlayerMP < 8 Then
            btnActionSpecial.Enabled = True
        ElseIf PlayerMP < 8 Then
            btnActionSpecial.Enabled = False
        End If

        If Not PlayerMP < 15 Then
            btnActionHeal.Enabled = True
        ElseIf PlayerMP < 15 Then
            btnActionHeal.Enabled = False
        End If

        pgrPlayerHealth.Value = PlayerHP
        pgrPlayerMagic.Value = PlayerMP
        pgrEnemyHealth.Value = EnemyHP

        If PlayerHP < 1 Then
            lblBattleText.Text = "You Died!"
            lblBattleText.ForeColor = Color.Red
            RestartGame()
        End If

        If EnemyHP < 1 Then
            lblBattleText.Text = "You Won!"
            lblBattleText.ForeColor = Color.Green
            RestartGame()
        End If
    End Sub

    Private Sub btnActionHeal_Click(sender As Object, e As EventArgs) Handles btnActionHeal.Click
        TotalHeal = 100 - PlayerHP
        TotalHeal = TotalHeal / 10
        TotalHeal = TotalHeal * 6 'Heal 60% of player's health.
        EnemyAttack = Rnd(11) + 10 'Damage from 10 to 20 towards player.

        PlayerHP = PlayerHP + TotalHeal
        PlayerHP = PlayerHP - EnemyAttack

        PlayerMP = PlayerMP - 15

        If PlayerMP > 50 Then
            PlayerMP = 50
        End If

        If PlayerHP < 0 Then
            PlayerHP = 0
        End If

        If PlayerHP > 100 Then
            PlayerHP = 100
        End If

        If EnemyHP < 0 Then
            EnemyHP = 0
        End If

        If Not PlayerMP < 8 Then
            btnActionSpecial.Enabled = True
        ElseIf PlayerMP < 8 Then
            btnActionSpecial.Enabled = False
        End If

        If Not PlayerMP < 15 Then
            btnActionHeal.Enabled = True
        ElseIf PlayerMP < 15 Then
            btnActionHeal.Enabled = False
        End If

        pgrPlayerHealth.Value = PlayerHP
        pgrPlayerMagic.Value = PlayerMP
        pgrEnemyHealth.Value = EnemyHP

        If PlayerHP < 1 Then
            lblBattleText.Text = "You Died!"
            lblBattleText.ForeColor = Color.Red
            RestartGame()
        End If

        If EnemyHP < 1 Then
            lblBattleText.Text = "You Won!"
            lblBattleText.ForeColor = Color.Green
            RestartGame()
        End If
    End Sub

    Private Sub MstHelpAbout_Click(sender As Object, e As EventArgs) Handles mstHelpAbout.Click
        MsgBox("Made by Rubiktor012, V. 1.0.0", 0, "About")
    End Sub

    Private Sub mstHelpFeedback_Click(sender As Object, e As EventArgs) Handles mstHelpFeedback.Click
        MsgBox("https://github.com/Rubiktor012/Simple-RPG-game-for-Windows/issues", 0, "Feedback")
    End Sub
End Class
