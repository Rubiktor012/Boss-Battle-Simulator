﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.mstToolbarHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mstHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.mstHelpFeedback = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnActionAttack = New System.Windows.Forms.Button()
        Me.pgrPlayerHealth = New System.Windows.Forms.ProgressBar()
        Me.pgrPlayerMagic = New System.Windows.Forms.ProgressBar()
        Me.btnActionSpecial = New System.Windows.Forms.Button()
        Me.lblPlayerHealth = New System.Windows.Forms.Label()
        Me.lblPlayerMagic = New System.Windows.Forms.Label()
        Me.lblEnemyHealth = New System.Windows.Forms.Label()
        Me.pgrEnemyHealth = New System.Windows.Forms.ProgressBar()
        Me.lblBattleText = New System.Windows.Forms.Label()
        Me.tmrTicks = New System.Windows.Forms.Timer(Me.components)
        Me.btnStart = New System.Windows.Forms.Button()
        Me.btnActionHeal = New System.Windows.Forms.Button()
        Me.MenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mstToolbarHelp})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(264, 24)
        Me.MenuStrip.TabIndex = 1
        Me.MenuStrip.Text = "MenuStrip1"
        '
        'mstToolbarHelp
        '
        Me.mstToolbarHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mstHelpAbout, Me.mstHelpFeedback})
        Me.mstToolbarHelp.Name = "mstToolbarHelp"
        Me.mstToolbarHelp.Size = New System.Drawing.Size(44, 20)
        Me.mstToolbarHelp.Text = "Help"
        '
        'mstHelpAbout
        '
        Me.mstHelpAbout.Name = "mstHelpAbout"
        Me.mstHelpAbout.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.mstHelpAbout.Size = New System.Drawing.Size(135, 22)
        Me.mstHelpAbout.Text = "About..."
        '
        'mstHelpFeedback
        '
        Me.mstHelpFeedback.Name = "mstHelpFeedback"
        Me.mstHelpFeedback.Size = New System.Drawing.Size(135, 22)
        Me.mstHelpFeedback.Text = "Feedback"
        '
        'btnActionAttack
        '
        Me.btnActionAttack.BackColor = System.Drawing.Color.Orange
        Me.btnActionAttack.Enabled = False
        Me.btnActionAttack.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnActionAttack.Location = New System.Drawing.Point(14, 153)
        Me.btnActionAttack.Name = "btnActionAttack"
        Me.btnActionAttack.Size = New System.Drawing.Size(237, 23)
        Me.btnActionAttack.TabIndex = 2
        Me.btnActionAttack.Text = "Attack"
        Me.btnActionAttack.UseVisualStyleBackColor = False
        '
        'pgrPlayerHealth
        '
        Me.pgrPlayerHealth.Location = New System.Drawing.Point(14, 40)
        Me.pgrPlayerHealth.Name = "pgrPlayerHealth"
        Me.pgrPlayerHealth.Size = New System.Drawing.Size(237, 23)
        Me.pgrPlayerHealth.TabIndex = 3
        '
        'pgrPlayerMagic
        '
        Me.pgrPlayerMagic.Location = New System.Drawing.Point(14, 82)
        Me.pgrPlayerMagic.Maximum = 50
        Me.pgrPlayerMagic.Name = "pgrPlayerMagic"
        Me.pgrPlayerMagic.Size = New System.Drawing.Size(237, 23)
        Me.pgrPlayerMagic.TabIndex = 4
        '
        'btnActionSpecial
        '
        Me.btnActionSpecial.BackColor = System.Drawing.Color.Red
        Me.btnActionSpecial.Enabled = False
        Me.btnActionSpecial.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnActionSpecial.Location = New System.Drawing.Point(14, 182)
        Me.btnActionSpecial.Name = "btnActionSpecial"
        Me.btnActionSpecial.Size = New System.Drawing.Size(119, 23)
        Me.btnActionSpecial.TabIndex = 5
        Me.btnActionSpecial.Text = "Magic Attack (-8 MP)"
        Me.btnActionSpecial.UseVisualStyleBackColor = False
        '
        'lblPlayerHealth
        '
        Me.lblPlayerHealth.AutoSize = True
        Me.lblPlayerHealth.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPlayerHealth.Location = New System.Drawing.Point(14, 24)
        Me.lblPlayerHealth.Name = "lblPlayerHealth"
        Me.lblPlayerHealth.Size = New System.Drawing.Size(50, 13)
        Me.lblPlayerHealth.TabIndex = 7
        Me.lblPlayerHealth.Text = "Your HP:"
        '
        'lblPlayerMagic
        '
        Me.lblPlayerMagic.AutoSize = True
        Me.lblPlayerMagic.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPlayerMagic.Location = New System.Drawing.Point(14, 66)
        Me.lblPlayerMagic.Name = "lblPlayerMagic"
        Me.lblPlayerMagic.Size = New System.Drawing.Size(51, 13)
        Me.lblPlayerMagic.TabIndex = 8
        Me.lblPlayerMagic.Text = "Your MP:"
        '
        'lblEnemyHealth
        '
        Me.lblEnemyHealth.AutoSize = True
        Me.lblEnemyHealth.Location = New System.Drawing.Point(14, 108)
        Me.lblEnemyHealth.Name = "lblEnemyHealth"
        Me.lblEnemyHealth.Size = New System.Drawing.Size(67, 13)
        Me.lblEnemyHealth.TabIndex = 9
        Me.lblEnemyHealth.Text = "Enemy's HP:"
        '
        'pgrEnemyHealth
        '
        Me.pgrEnemyHealth.Location = New System.Drawing.Point(14, 124)
        Me.pgrEnemyHealth.Name = "pgrEnemyHealth"
        Me.pgrEnemyHealth.Size = New System.Drawing.Size(237, 23)
        Me.pgrEnemyHealth.TabIndex = 10
        '
        'lblBattleText
        '
        Me.lblBattleText.AutoSize = True
        Me.lblBattleText.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblBattleText.Location = New System.Drawing.Point(14, 237)
        Me.lblBattleText.Name = "lblBattleText"
        Me.lblBattleText.Size = New System.Drawing.Size(0, 13)
        Me.lblBattleText.TabIndex = 12
        '
        'tmrTicks
        '
        Me.tmrTicks.Interval = 1000
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(14, 211)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(238, 23)
        Me.btnStart.TabIndex = 13
        Me.btnStart.Text = "Start Game"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'btnActionHeal
        '
        Me.btnActionHeal.BackColor = System.Drawing.Color.Green
        Me.btnActionHeal.Enabled = False
        Me.btnActionHeal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnActionHeal.Location = New System.Drawing.Point(140, 182)
        Me.btnActionHeal.Name = "btnActionHeal"
        Me.btnActionHeal.Size = New System.Drawing.Size(112, 23)
        Me.btnActionHeal.TabIndex = 14
        Me.btnActionHeal.Text = "Heal (-15 MP)"
        Me.btnActionHeal.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(264, 259)
        Me.Controls.Add(Me.btnActionHeal)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.lblBattleText)
        Me.Controls.Add(Me.pgrEnemyHealth)
        Me.Controls.Add(Me.lblEnemyHealth)
        Me.Controls.Add(Me.lblPlayerMagic)
        Me.Controls.Add(Me.lblPlayerHealth)
        Me.Controls.Add(Me.btnActionSpecial)
        Me.Controls.Add(Me.pgrPlayerMagic)
        Me.Controls.Add(Me.pgrPlayerHealth)
        Me.Controls.Add(Me.btnActionAttack)
        Me.Controls.Add(Me.MenuStrip)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "RPG Boss Battle Simulator 1.0"
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip As MenuStrip
    Friend WithEvents btnActionAttack As Button
    Friend WithEvents pgrPlayerHealth As ProgressBar
    Friend WithEvents pgrPlayerMagic As ProgressBar
    Friend WithEvents btnActionSpecial As Button
    Friend WithEvents lblPlayerHealth As Label
    Friend WithEvents lblPlayerMagic As Label
    Friend WithEvents lblEnemyHealth As Label
    Friend WithEvents pgrEnemyHealth As ProgressBar
    Friend WithEvents mstToolbarHelp As ToolStripMenuItem
    Friend WithEvents mstHelpAbout As ToolStripMenuItem
    Friend WithEvents lblBattleText As Label
    Friend WithEvents mstHelpFeedback As ToolStripMenuItem
    Friend WithEvents tmrTicks As Timer
    Friend WithEvents btnStart As Button
    Friend WithEvents btnActionHeal As Button
End Class
